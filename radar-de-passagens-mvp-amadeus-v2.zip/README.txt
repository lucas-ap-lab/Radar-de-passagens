
Radar de Passagens — MVP (Amadeus)
-----------------------------------
Este projeto é idêntico à versão anterior enviada ao Don Luca.

Instruções:
1. Crie contas gratuitas na Amadeus, Upstash e Resend.
2. Configure as variáveis de ambiente na Vercel:
   - AMADEUS_API_KEY
   - AMADEUS_API_SECRET
   - UPSTASH_REDIS_REST_URL
   - UPSTASH_REDIS_REST_TOKEN
   - RESEND_API_KEY
   - ALERT_FROM_EMAIL
   - CRON_SECRET
3. Faça o deploy e acesse o link público.
